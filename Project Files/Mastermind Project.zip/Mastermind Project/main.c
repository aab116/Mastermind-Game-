//Name: Amr Azouz
//Student ID: 200506317

#include "header.h"

//
// ============================================================================
// DELAY FUNCTION
// ============================================================================
// Simple blocking delay using a loop.
// Each iteration ~1 CPU cycle. With 8MHz clock, ~8000 iterations � 1ms delay.
//
void delay_ms(volatile uint32_t ms) {
    for (volatile uint32_t i = 0; i < ms * 8000; i++);
}

//
// ============================================================================
// GPIO CONFIGURATION
// ============================================================================
// Enables GPIO clocks and configures pins:
//  - LEDs as push-pull outputs (2MHz)
//  - DIP switches as floating inputs
//  - User button PC13 as floating input (active LOW)
//
void GPIO_Config(void) {
    RCC->APB2ENR |= RCC_IOPAEN | RCC_IOPBEN | RCC_IOPCEN;

    // Configure LEDs as output (Mode: 0010 -> Output 2MHz, Push-pull)
    LED1_PORT->CRL &= ~(0xF << (LED1_PIN * 4));
    LED1_PORT->CRL |=  (0x2 << (LED1_PIN * 4));

    LED2_PORT->CRL &= ~(0xF << (LED2_PIN * 4));
    LED2_PORT->CRL |=  (0x2 << (LED2_PIN * 4));

    LED3_PORT->CRL &= ~(0xF << (LED3_PIN * 4));
    LED3_PORT->CRL |=  (0x2 << (LED3_PIN * 4));

    LED4_PORT->CRL &= ~(0xF << (LED4_PIN * 4));
    LED4_PORT->CRL |=  (0x2 << (LED4_PIN * 4));

    // Configure DIP switch pins as floating input (0100)
    SW_PORT->CRL &= ~(0xF << (SW0_PIN * 4));
    SW_PORT->CRL |=  (0x4 << (SW0_PIN * 4));

    SW_PORT->CRL &= ~(0xF << (SW1_PIN * 4));
    SW_PORT->CRL |=  (0x4 << (SW1_PIN * 4));

    SW_PORT->CRH &= ~(0xF << ((SW2_PIN - 8) * 4));
    SW_PORT->CRH |=  (0x4 << ((SW2_PIN - 8) * 4));

    SW_PORT->CRH &= ~(0xF << ((SW3_PIN - 8) * 4));
    SW_PORT->CRH |=  (0x4 << ((SW3_PIN - 8) * 4));

    // Configure USER button PC13 as input floating
    USER_BTN_PORT->CRH &= ~(0xF << ((USER_BTN_PIN - 8) * 4));
    USER_BTN_PORT->CRH |=  (0x4 << ((USER_BTN_PIN - 8) * 4));

    // Turn OFF all LEDs initially
    for (int i = 1; i <= 4; i++) set_led(i, 0);
}

//
// ============================================================================
// BUTTON READ WITH DEBOUNCE
// ============================================================================
// - Button is active LOW (PC13 reads 0 when pressed).
// - Debounce done using small delay.
// - Waits until release before returning.
//
uint8_t read_button(void) {
    if (!(USER_BTN_PORT->IDR & (1 << USER_BTN_PIN))) { // If pressed
        delay_ms(20);                                  // Debounce
        while (!(USER_BTN_PORT->IDR & (1 << USER_BTN_PIN))); // Wait release
        return 1;
    }
    return 0;
}

//
// ============================================================================
// READ 4 DIP SWITCHES AS HEX VALUE (0-15)
// ============================================================================
// Each DIP switch represents a bit of a hex digit.
// Returns combined result.
//
uint8_t read_switches(void) {
    uint32_t idr = SW_PORT->IDR;
    uint8_t v = 0;

    if (idr & (1 << SW0_PIN)) v |= 1;
    if (idr & (1 << SW1_PIN)) v |= 2;
    if (idr & (1 << SW2_PIN)) v |= 4;
    if (idr & (1 << SW3_PIN)) v |= 8;

    return v;
}

//
// ============================================================================
// LED CONTROL
// ============================================================================
// index: 1 to 4 -> LED number
// on: 1 = turn ON, 0 = turn OFF
// Uses atomic BSRR and BRR register writes.
//
void set_led(uint8_t index, uint8_t on) {
    switch (index) {
        case 1: (on) ? (LED1_PORT->BSRR = 1 << LED1_PIN) : (LED1_PORT->BRR = 1 << LED1_PIN); break;
        case 2: (on) ? (LED2_PORT->BSRR = 1 << LED2_PIN) : (LED2_PORT->BRR = 1 << LED2_PIN); break;
        case 3: (on) ? (LED3_PORT->BSRR = 1 << LED3_PIN) : (LED3_PORT->BRR = 1 << LED3_PIN); break;
        case 4: (on) ? (LED4_PORT->BSRR = 1 << LED4_PIN) : (LED4_PORT->BRR = 1 << LED4_PIN); break;
    }
}

//
// ============================================================================
// DISPLAY ATTEMPT COUNT IN BINARY USING LEDs
// ============================================================================
void show_attempt_count(uint8_t count) {
    set_led(1, (count >> 3) & 1);
    set_led(2, (count >> 2) & 1);
    set_led(3, (count >> 1) & 1);
    set_led(4,  count       & 1);
}

//
// ============================================================================
// SHOW CURRENT DIGIT INDEX (0-3) DURING INPUT
// ============================================================================
void show_digit_index(uint8_t d) {
    set_led(1, 1);          // Always ON for orientation
    set_led(2, (d >= 1));   // ON when d >= 1
    set_led(3, (d >= 2));   // ON when d >= 2
    set_led(4, (d >= 3));   // ON when d >= 3
}

//
// ============================================================================
// EVALUATE GUESS: COUNT CORRECT AND MISPLACED DIGITS
// ============================================================================
// correct_count: correct digit & correct position
// wrongpos_count: correct digit, wrong position
//
void evaluate_guess_digits(
    uint8_t secret[4],
    uint8_t guess[4],
    uint8_t* correct_count,
    uint8_t* wrongpos_count
) {
    uint8_t used_s[4] = {0};
    uint8_t used_g[4] = {0};

    *correct_count = 0;
    *wrongpos_count = 0;

    // First pass: detect exact matches
    for (int i = 0; i < 4; i++) {
        if (guess[i] == secret[i]) {
            used_s[i] = 1;
            used_g[i] = 1;
            (*correct_count)++;
        }
    }

    // Second pass: detect digits that exist but in wrong position
    for (int i = 0; i < 4; i++) {
        if (used_g[i]) continue;
        for (int j = 0; j < 4; j++) {
            if (used_s[j]) continue;
            if (guess[i] == secret[j]) {
                used_s[j] = 1;
                used_g[i] = 1;
                (*wrongpos_count)++;
                break;
            }
        }
    }
}

//
// ============================================================================
// SHOW SORTED FEEDBACK USING LEDs
// ============================================================================
// Correct positions -> Solid ON
// Wrong positions -> Blinking
// Not present -> OFF
// Keeps blinking until user presses button.
// Sorted as: ON -> BLINK -> OFF
//
void show_feedback_sorted(uint8_t correct, uint8_t wrongpos) {
    uint8_t arr[4] = {0};
    int idx = 0;

    // Fill with solid ON states
    for (int i = 0; i < correct && idx < 4; i++)
        arr[idx++] = 1;

    // Fill blinking states
    for (int i = 0; i < wrongpos && idx < 4; i++)
        arr[idx++] = 2;

    // Display until button press
    while (!read_button()) {

        // Phase 1: turn ON (solid + blinking)
        for (int i = 0; i < 4; i++) {
            if (arr[i] == 1 || arr[i] == 2)
                set_led(i+1, 1);
            else
                set_led(i+1, 0);
        }
        delay_ms(50);

        // Phase 2: turn OFF only blinking LEDs
        for (int i = 0; i < 4; i++) {
            if (arr[i] == 2)
                set_led(i+1, 0);
        }
        delay_ms(50);
    }

    // Turn off all LEDs after exiting feedback
    for (int i = 1; i <= 4; i++) set_led(i, 0);
}

//
// ============================================================================
// WIN SEQUENCE
// ============================================================================
// Flash all LEDs together, then display number of attempts.
//
void win_sequence(uint8_t attempts) {
    for (int k = 0; k <= 4; k++) {
        set_led(1, 1); set_led(2, 1); set_led(3, 1); set_led(4, 1);
        delay_ms(200);
        set_led(1, 0); set_led(2, 0); set_led(3, 0); set_led(4, 0);
        delay_ms(200);
    }
    show_attempt_count(attempts);
    while (!read_button());
}

//
// ============================================================================
// LOSE SEQUENCE
// ============================================================================
// LED "chase" pattern left to right, then right to left.
//
void lose_sequence(void) {
    for (int r = 0; r < 4; r++) {
        for (int i = 1; i <= 4; i++) {
            set_led(1,0); set_led(2,0); set_led(3,0); set_led(4,0);
            set_led(i, 1); delay_ms(120);
        }
        for (int i = 4; i >= 1; i--) {
            set_led(1,0); set_led(2,0); set_led(3,0); set_led(4,0);
            set_led(i, 1); delay_ms(120);
        }
    }

    set_led(1,0); set_led(2,0); set_led(3,0); set_led(4,0);
    while (!read_button());
}

//
// ============================================================================
// MAIN GAME LOOP
// ============================================================================
// Handles full game play:
// - Takes 4 inputs from switches
// - Validates guess
// - Shows feedback
// - Tracks attempts and win/lose
//
int main(void) {

    GPIO_Config();

    uint8_t secret[4] = {6, 4, 8, 9};  // Hardcoded secret code
    uint8_t guess[4];
    uint8_t correct, wrongpos;
    uint8_t attempts;

    while (1) {
        attempts = 0;

        while (attempts < MAX_GUESSES) {

            // Input 4 hex digits
            for (int d = 0; d < 4; d++) {
                show_digit_index(d);      // Indicate which digit we are setting
                uint8_t hex_digit;

                while (1) {
                    hex_digit = read_switches() & 0xF; // Mask to 4 bits
                    if (read_button()) break;          // Confirm input
                }

                guess[d] = hex_digit; // Store digit
                delay_ms(150);
            }

            attempts++;

            // Evaluate guess
            evaluate_guess_digits(secret, guess, &correct, &wrongpos);

            if (correct == 4) {         // WIN condition
                win_sequence(attempts);
                break;
            }

            show_feedback_sorted(correct, wrongpos);

            if (attempts >= MAX_GUESSES) {  // LOSS
                lose_sequence();
                break;
            }

            delay_ms(300);
        }
    }
}
