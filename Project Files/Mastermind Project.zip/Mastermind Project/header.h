//Name: Amr Azouz
//Student ID: 200506317


#ifndef MAIN_H
#define MAIN_H

#include <stdint.h> // Provides fixed-width integer types (e.g., uint8_t, uint32_t)

/*
============================================================================
                        REGISTER STRUCT DEFINITIONS
============================================================================
These structs map to actual hardware registers in STM32F103RB.
They allow us to access registers using names like GPIOA->ODR instead
of manually dealing with memory addresses.
*/

// Structure representing GPIO registers for STM32F103RB
typedef struct {
    volatile uint32_t CRL;   // Port configuration register low (pins 0-7)
    volatile uint32_t CRH;   // Port configuration register high (pins 8-15)
    volatile uint32_t IDR;   // Input data register
    volatile uint32_t ODR;   // Output data register
    volatile uint32_t BSRR;  // Bit set/reset register (atomic set/reset)
    volatile uint32_t BRR;   // Bit reset register (atomic reset)
    volatile uint32_t LCKR;  // Port configuration lock register
} GPIO_TypeDef;

// Structure representing RCC (Reset and Clock Control) registers
typedef struct {
    volatile uint32_t CR;        // Clock control register
    volatile uint32_t CFGR;      // Clock configuration register
    volatile uint32_t CIR;       // Clock interrupt register
    volatile uint32_t APB2RSTR;  // APB2 peripheral reset register
    volatile uint32_t APB1RSTR;  // APB1 peripheral reset register
    volatile uint32_t AHBENR;    // AHB peripheral clock enable
    volatile uint32_t APB2ENR;   // APB2 peripheral clock enable
    volatile uint32_t APB1ENR;   // APB1 peripheral clock enable
    volatile uint32_t BDCR;      // Backup domain control
    volatile uint32_t CSR;       // Control/status register
} RCC_TypeDef;

/*
============================================================================
                         BASE ADDRESSES (MEMORY MAP)
============================================================================
These addresses are provided by STM32 memory map.
We use pointer casting to create references to specific
peripheral register blocks.
*/

#define PERIPH_BASE       0x40000000UL                     // Base for all peripheral addresses
#define APB2PERIPH_BASE   (PERIPH_BASE + 0x00010000UL)     // APB2 peripheral base address
#define AHBPERIPH_BASE    (PERIPH_BASE + 0x00020000UL)     // AHB peripheral base address

// Base addresses of specific peripherals
#define GPIOA_BASE  (APB2PERIPH_BASE + 0x0800UL)  // GPIOA base address
#define GPIOB_BASE  (APB2PERIPH_BASE + 0x0C00UL)  // GPIOB base address
#define GPIOC_BASE  (APB2PERIPH_BASE + 0x1000UL)  // GPIOC base address
#define RCC_BASE    (AHBPERIPH_BASE  + 0x1000UL)  // RCC base address

// Create pointers to structs at those base addresses
#define GPIOA   ((GPIO_TypeDef*) GPIOA_BASE)
#define GPIOB   ((GPIO_TypeDef*) GPIOB_BASE)
#define GPIOC   ((GPIO_TypeDef*) GPIOC_BASE)
#define RCC     ((RCC_TypeDef*)  RCC_BASE)

/*
============================================================================
                    RCC CLOCK ENABLE BIT MASKS
============================================================================
These bit masks are used to enable clocks for GPIOA, GPIOB, GPIOC.
We OR them into RCC->APB2ENR.
*/

#define RCC_IOPAEN   (1U << 2)  // Enable clock for GPIOA
#define RCC_IOPBEN   (1U << 3)  // Enable clock for GPIOB
#define RCC_IOPCEN   (1U << 4)  // Enable clock for GPIOC

/*
============================================================================
                          PIN ASSIGNMENTS
============================================================================
Mapping each GPIO pin to its purpose in the game.
- LEDs represent feedback or attempt count
- DIP switches are used for inputting guessing digits
- User button confirms selections and navigates game states
*/

// LED connections (from LEFT to RIGHT)
#define LED1_PORT   GPIOA
#define LED1_PIN    0   // Represents Bit3 (MSB) of feedback/status
#define LED2_PORT   GPIOA
#define LED2_PIN    1   // Represents Bit2
#define LED3_PORT   GPIOA
#define LED3_PIN    4   // Represents Bit1
#define LED4_PORT   GPIOB
#define LED4_PIN    0   // Represents Bit0 (LSB)

// DIP switch inputs (hex digit input)
#define SW_PORT     GPIOB
#define SW0_PIN     4   // LSB bit of input
#define SW1_PIN     6   // Bit1
#define SW2_PIN     8   // Bit2
#define SW3_PIN     9   // MSB (bit 3)

// User push button (active LOW)
#define USER_BTN_PORT   GPIOC
#define USER_BTN_PIN    13

#define MAX_GUESSES 8   // Maximum number of allowed attempts before losing

/*
============================================================================
                      FUNCTION PROTOTYPES
============================================================================
Declarations of all functions implemented in main.c.
These are used for GPIO control, input reading, game logic,
LED display, and animations.
*/

// Basic initialization
void GPIO_Config(void);        // Configures all GPIO pins
void delay_ms(volatile uint32_t ms); // Simple delay loop (blocking)

// Input functions
uint8_t read_button(void);     // Returns 1 when button is pressed (active LOW)
uint8_t read_switches(void);   // Reads 4-bit input (0�15) from DIP switches

// LED control
void set_led(uint8_t index, uint8_t on); // Turn ON/OFF individual LED (1-4)
void show_digit_index(uint8_t d);        // Visual indicator for current digit position

// Game logic processing
void evaluate_guess_digits(
    uint8_t secret[4],          // Secret code array (4 digits)
    uint8_t guess[4],           // Player's guess array (4 digits)
    uint8_t* correct_count,     // Output: right digit, right position
    uint8_t* wrongpos_count     // Output: right digit, wrong position
);

// Feedback and display
void show_feedback_sorted(uint8_t correct, uint8_t wrongpos); // Sorted LED feedback
void show_attempt_count(uint8_t count);  // Displays attempt number in binary
void win_sequence(uint8_t attempts);     // LED sequence on win
void lose_sequence(void);               // LED sequence on loss

#endif
